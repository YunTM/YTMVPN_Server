﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Net;
using System.Text;

namespace YBTVPN_Server.Core
{
    public class ServerSocket
    {
        SocketAsyncEventArgsPool readEventArgsPool;
        SocketAsyncEventArgsPool sendEventArgsPool;
        Socket socket;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="addressFamily"></param>
        /// <param name="socketType"></param>
        /// <param name="protocolType"></param>
        public ServerSocket(AddressFamily addressFamily, SocketType socketType, ProtocolType protocolType)
        {
            //准备对象
            readEventArgsPool = new SocketAsyncEventArgsPool(CreateReadEventArgs, 50);
            for (int i = 0; i < 50; i++)
            {
                readEventArgsPool.PutObj(CreateReadEventArgs());
            }

            sendEventArgsPool = new SocketAsyncEventArgsPool(CreateSendEventArgs, 50);
            for (int i = 0; i < 50; i++)
            {
                sendEventArgsPool.PutObj(CreateSendEventArgs());
            }

            socket = new Socket(addressFamily, socketType, protocolType);
        }

        public void StartWorking(IPEndPoint localEP)
        {
            //绑定端口
            socket.Bind(localEP);
            LogHelper.Log("binding " + localEP.Address + ":" + localEP.Port);

            //!!!!!异步接收 不会写SocketAsyncArgs啊卧槽
            socket.ReceiveMessageFromAsync(readEventArgsPool.GetObj());
        }

        /// <summary>
        /// readEventArgsPool创建对象时的函数
        /// </summary>
        /// <returns></returns>
        SocketAsyncEventArgs CreateReadEventArgs()
        {
            //remote = new IPEndPoint(IPAddress.Any, 0);
            //buffer = new byte[4096]; //!MTU这里需要修改
            SocketAsyncEventArgs e = new SocketAsyncEventArgs();
            e.SetBuffer(new byte[4096], 0, 4096);
            e.Completed += Read_Completed;
            return e;
        }
        /// <summary>
        /// sendEventArgsPool创建对象时的函数
        /// </summary>
        /// <returns></returns>
        SocketAsyncEventArgs CreateSendEventArgs()
        {
            SocketAsyncEventArgs e = new SocketAsyncEventArgs();
            e.SetBuffer(new byte[4096], 0, 4096);
            e.Completed += Send_Completed;
            return e;
        }

        /// <summary>
        /// 读操作完成
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Read_Completed(object sender, SocketAsyncEventArgs e)
        {
            //先异步接收下一个
            socket.ReceiveMessageFromAsync(readEventArgsPool.GetObj());

            //丢入队列
            Program.RoutingService.RecvQueue.Enqueue(new Routing.RoutingPackge(e.RemoteEndPoint, e.Buffer));

            //还给对象池
            readEventArgsPool.PutObj(e);


            return;
            //!!这是啥？自动生成的
            //throw new NotImplementedException();
        }

        /// <summary>
        /// 发送操作完成
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Send_Completed(object sender, SocketAsyncEventArgs e)
        {
            //还给对象池
            sendEventArgsPool.PutObj(e);

            return;
            //!!这是啥？自动生成的
            //throw new NotImplementedException();
        }

        /// <summary>
        /// 异步发送Raw数据
        /// </summary>
        /// <param name="dst"></param>
        /// <param name="data"></param>
        public void SendAsync(IPEndPoint dst, byte[] data)
        {
            SocketAsyncEventArgs e = sendEventArgsPool.GetObj();
            e.RemoteEndPoint = dst;
            e.SetBuffer(data, 0, data.Length);
            socket.SendToAsync(e);
        }
    }
}
