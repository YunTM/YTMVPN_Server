﻿using System;
using CommandLine;
using CommandLine.Text;
using YBTVPN_Server.Core;
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace YBTVPN_Server
{
    class Program
    {
        public static Options options;
        public static byte[] LogicAddrByteArray;

        public static ServerSocket ServerSocket;
        


        static void Main(string[] args)
        {
            //!处理参数（判读参数正确性）
            CommandLine.Parser.Default.ParseArguments<Options>(args).WithParsed<Options>(parsed => options = parsed);
            LogHelper.Log("Bind: " + options.Bind);
            LogHelper.Log("Port: " + options.Port);
            LogHelper.Log("LogicAddrLength :" + options.LogicAddrLength);
            LogHelper.Log("LogicAddr: " + options.LogicAddr);
            LogHelper.Log("LogicPortLength :" + options.LogicPortLength);

            //计算一些值便于之后工作
            #region 计算LogicAddrByteArray
            //!!注意跨平台的字节序 Intel小端转大端
            byte[] result = BitConverter.GetBytes(options.LogicAddr);
            if (result.Length == options.LogicAddrLength)
            {
                LogicAddrByteArray = result;
            }
            else if (result.Length > options.LogicAddrLength)
            {
                throw new Exception("LogicAddr超出LogicAddrLength大小");
            }
            else
            {
                LogicAddrByteArray = new byte[options.LogicAddrLength];
                for (int i = 0; i < result.Length; i++)
                {
                    LogicAddrByteArray[LogicAddrByteArray.Length - 1 - i] = result[i];
                }

            }

            #endregion

            //初始化ServerSocket
            ServerSocket = new ServerSocket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            //开始工作
            ServerSocket.StartWorking(new IPEndPoint(IPAddress.Parse(options.Bind), options.Port));


            //防止跳出
            while (true)
            {
                Thread.Sleep(10);
            }
        }
    }

}