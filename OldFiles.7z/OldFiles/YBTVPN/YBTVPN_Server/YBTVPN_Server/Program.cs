﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using CommandLine;
using CommandLine.Text;
using YBTVPN_Server.Routing;
using YBTVPN_Server.Control;

namespace YBTVPN_Server
{
    class Program
    {
        public static Options options = new Options();
        public static RoutingService RoutingService = new RoutingService();  //路由服务
        public static ControlService ControlService = new ControlService();  //控制服务

        public static ushort LogicAddrByteLength;  //LogicAddr占用字节长度
        public static ushort LogicAddrFreeBit;  //LogicAddr所需字节的多余位
        public static ushort LogicPortByteLength;  //LogicPort占用字节长度
        //public static ushort LogicPortByteOffset;  //LogicPort占用字节的偏移
        //public static ushort LogicPortFreeBit;  //LogicPort所需字节的多余位
        //public static ushort LogicAddrAndPortByteLength;  //LogicAddrAndPort字节长度
        //public static ushort LogicAddrAndPortFreeBit;  //LogicAddrAndPort所需字节的多余位

        //public static Queue PortForwardQueue = new Queue();  //!端口转发队列
        //public static Queue AgentQueue = new Queue();  //!代理队列

        static void Main(string[] args)
        {
            //!处理参数（判读参数正确性）

            if (CommandLine.Parser.Default.ParseArguments(args, options))
            {
                Log.Logging("Bind: " + options.Bind);
                Log.Logging("Port: " + options.Port);
                Log.Logging("LogicAddrLength :" + options.LogicAddrLength);
                Log.Logging("LogicAddr: " + options.LogicAddr);
                Log.Logging("LogicPortLength :" + options.LogicPortLength);
                Log.Logging("LogicNet: " + options.LogicNet);

                //计算一些数字便于之后工作
                //计算LogicAddr占用字节
                LogicAddrByteLength = (ushort)Math.Ceiling((double)(options.LogicAddrLength / 8));
                //计算LogicAddr所需字节的多余位
                LogicAddrFreeBit = (ushort)(options.LogicAddrLength % 8);
                //计算LogicPort占用字节
                LogicPortByteLength = (ushort)Math.Ceiling((double)((options.LogicPortLength) / 8));
                //计算LogicPort占用字节的偏移
                //LogicPortByteOffset = ;
                //计算LogicPort所需字节的多余位
                //LogicPortFreeBit = (ushort)(options.LogicPortLength % 8);
                ////计算LogicAddrAndPort占用字节
                //LogicAddrAndPortByteLength = (ushort)Math.Ceiling((double)((options.LogicAddrLength + options.LogicPortLength) / 8));
                ////计算LogicAddrAndPort所需字节的多余位
                //LogicPortFreeBit = (ushort)(options.LogicAddrLength + options.LogicPortLength % 8);
            }
            else
            {
                // Display the default usage information
                Console.WriteLine(options.GetUsage());
                return;
            }

            //初始化路由表条目
            RoutingService.RoutingTable.Add(LogicAddrBoolArray,ControlService.ServiceQueue,);  //控制服务


            //!启动线程池任务
            ThreadPool.QueueUserWorkItem(new WaitCallback(RoutingService.Do));  //路由服务
            ThreadPool.QueueUserWorkItem(new WaitCallback(ControlService.Do));  //控制服务


            //绑定socket
            ServerSocket serverSocket = new ServerSocket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            Log.Logging("binding " + options.Bind + ":" + options.Port);
            serverSocket.Bind(new IPEndPoint(IPAddress.Parse(options.Bind), options.Port));

            //开始工作
            serverSocket.StartWork();

  

            //!需要处理退出
            while (true)
            {
                Console.ReadKey();
            }
        }

        




    }
}
