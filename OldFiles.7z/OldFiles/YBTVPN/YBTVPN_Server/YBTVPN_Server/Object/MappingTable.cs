﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace YBTVPN_Server.Object
{
    public class MappingTable
    {
        public List<MappingItem> Items;

        public void Add(MappingItem mappingItem)
        {
            Items.Add(mappingItem);
            
        }

        public EndPoint Query(bool[] logicAddr)
        {
            return Items.Find(item => item.LogicAddr.Find(logicAddrFromTable => logicAddrFromTable == logicAddr) == logicAddr).Endpoint;
        }


    }
    public struct MappingItem
    {
        public EndPoint Endpoint;
        public List<bool[]> LogicAddr;
        public MappingItem(EndPoint endPoint, bool[] logicAddr)
        {
            Endpoint = endPoint;
            LogicAddr = new List<bool[]>();
            LogicAddr.Add(logicAddr);
        }
        public MappingItem(EndPoint endPoint, List<bool[]> logicAddr)
        {
            Endpoint = endPoint;
            LogicAddr = logicAddr;
        }

    }



}
