﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using YBTVPN_Server.Object.Routing;

namespace YBTVPN_Server.Control
{
    class ControlService
    {
        public static Queue<RoutingPackge> ServiceQueue = new Queue<RoutingPackge>();
        public RoutingTable RoutingTable = new RoutingTable();

        public void Do(object state)
        {

        }



        //握手


        //!!!处理握手先
        //判断是否为本地逻辑地址
        //if (ro.data[0] == options.LogicAddr)
        //{
        //    //存入端口转发队列
        //    //!线程安全
        //    PortForwardQueue.Enqueue(ro);
        //}
        //else
        //{
        //    //发送出去
        //    //!!需要维护一个路由表
        //}
    }
}
