﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YBTVPN_Server.Object.Routing
{
    /// <summary>
    /// 这是个假队列，入队的RoutingPackage将立即通过ServerSocket异步发出去。
    /// 队列标记在路由表中。
    /// 这样不用扩大路由表字段，也不用判断目标地址是本地还是远端。
    /// </summary>
    class RoutingOutgoingQueue :Queue<RoutingPackge>
    {
        /// <summary>
        /// 这是个假队列，入队的RoutingPackage将立即通过ServerSocket异步发出去
        /// </summary>
        /// <param name="item"></param>
        public static new void Enqueue(RoutingPackge item)
        {
            //!!!!异步发送
        }
    }
}
