﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using YBTVPN_Server.Object;
using System.Threading;

namespace YBTVPN_Server.Routing
{
    class RoutingService
    {
        public static Queue<RoutingPackge> ServiceQueue = new Queue<RoutingPackge>();
        public RoutingTable RoutingTable = new RoutingTable();

        public void Do(object state)
        {
            //初始化局部变量
            byte[] destAddr = new byte[Program.LogicAddrByteLength];  //目标地址寄存器
            byte[] destPort = new byte[Program.LogicPortByteLength];  //目标端口寄存器

            //!!重新看一遍 需要优化很多
            //!需要处理退出
            while (true)
            {
                //!线程安全
                while (ServiceQueue.Count > 0)
                {
                    //从队列取出
                    RoutingPackge rp = ServiceQueue.Dequeue();
                    Log.Logging("RoutingService: Dequeue!");

                    //计算目标地址和端口
                    Buffer.BlockCopy(rp.Data, 0, destAddr, 0, Program.LogicAddrByteLength);  //地址
                    Buffer.BlockCopy(rp.Data, Program.LogicAddrByteLength, destPort, 0, Program.LogicPortByteLength);  //端口
                    destPort. >> Program.LogicAddrFreeBit + Program.LogicPortByteLength //右移清空小端右边的其他字节

                    destAddr[destAddr.Length] >>= Program.LogicAddrFreeBit;  

                    //!!路由 需要维护路由表
                    //!!默认路由

                    Queue<RoutingPackge> q = RoutingTable.GetQueueByAddr(
                        RoutingTools.Byte2BoolArray(rp.Data, Program.options.LogicAddrLength),
                        RoutingTools.Byte2BoolArray(rp.Data, Program.options.LogicPortLength, Program.options.LogicAddrLength));
                    if (q != null)
                    {
                        //!!线程安全
                        //交给了目标队列
                        q.Enqueue(rp);
                    }
                    else
                    {
                        //查询不到路由 目标不可达
                        Log.Logging("DestAddr Unreachable: " + Convert.ToUInt64(RoutingTools.Byte2BoolArray(rp.Data, Program.options.LogicAddrLength, 0)));
                    }


                }
                //休眠
                Thread.Sleep(10);
            }

        }



    }
}
