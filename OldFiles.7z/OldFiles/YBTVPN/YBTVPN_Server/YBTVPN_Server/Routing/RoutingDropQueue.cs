﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YBTVPN_Server.Object.Routing
{
    //!是否用上了？

    /// <summary>
    /// 这是个假队列，入队的RoutingPackage将被丢弃。
    /// 队列标记在路由表中。
    /// 这样不用在路由工作线程中判断是否该丢弃。
    /// </summary>
    class RoutingDropQueue : Queue<RoutingPackge>
    {
        /// <summary>
        /// 这是个假队列，入队的RoutingPackage将被丢弃
        /// </summary>
        /// <param name="item"></param>
        public static new void Enqueue(RoutingPackge item)
        {
            //!!LOG
        }
    }
}
