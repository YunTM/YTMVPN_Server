﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YBTVPN_Server.Routing
{
    public static class RoutingTools
    {
        ///// <summary>
        ///// 从value取length个比特，偏移offset个比特
        ///// </summary>
        ///// <param name="value"></param>
        ///// <param name="length"></param>
        ///// <param name="offset"></param>
        //public static bool[] Byte2BoolArray(byte[] value, ushort length, ushort offset = 0)
        //{
        //    !这里吐槽一下，写这个函数的时候真是神TM恶心
        //    bool[] b = new bool[value.Length * 8];
        //    value = value.Reverse().ToArray();  //预先对字节数组反向排序，因为后面转换导致比特的高低位不正确
        //    new BitArray(value).CopyTo(b, 0);  //!能不能优化一下，这里把value完整的转换成了bool[]再复制指定部分
        //    b = b.Reverse().ToArray();  //对比特反向排序，还原高低位

        //    bool[] r = new bool[length];
        //    Array.ConstrainedCopy(b,offset,r,0,length);  //复制需要的比特
        //    !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!辣鸡思路弃坑
        //    return r;
        //}

        /// <summary>
        /// byte数组位右移 多余位丢弃
        /// 注意：Big Endian字节序
        /// </summary>
        /// <returns></returns>
        public static byte[] RightShift(byte[] array, ushort count)
        {
            array[array.Length - 1] >>= count;  //先移动最右边的
            //从右向左处理
            for (int i = array.Length - 2; i >= 0; i--)
            {
                array[i + 1] += (byte)(array[i] << 8 - count);  //恢复上一个byte的左端
                array[i] >>= count;  //右移
            }
            return array;
        }

        /// <summary>
        /// byte数组位左移 多余位丢弃
        /// 注意：Big Endian字节序
        /// </summary>
        /// <returns></returns>
        public static byte[] LeftShift(byte[] array, ushort count)
        {
            array[array.Length - 1] <<= count;  //先移动最左边的
            //从左向右处理
            for (int i = 1; i < array.Length; i++)
            {
                array[i - 1] += (byte)(array[i] >> 8 - count);  //恢复上一个byte的右端
                array[i] <<= count;  //左移
            }
            return array;
        }


    }
}
