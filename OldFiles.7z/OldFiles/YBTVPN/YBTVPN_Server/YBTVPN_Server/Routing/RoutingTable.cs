﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YBTVPN_Server.Routing
{
    /// <summary>
    /// 路由表支持端口匹配查询
    /// </summary>
    class RoutingTable
    {
        public List<RoutingItem> Items = new List<RoutingItem>();

        public void Add(byte[] destAddr, Queue<RoutingPackge> outputQueue, byte[] destPort = null)
        {
            Items.Add(new RoutingItem(destAddr, outputQueue, destPort));
        }
        /// <summary>
        /// 支持端口匹配查询，若没有匹配的端口或destPort为null，返回相应的logicAddr查询结果。
        /// logicAddr没有匹配结果将返回null。
        /// </summary>
        /// <param name="logicAddr">注意：Big Endian字节序</param>
        /// <param name="destPort">注意：Big Endian字节序</param>
        /// <returns></returns>
        public RoutingItem? Query(byte[] logicAddr, byte[] destPort = null)
        {
            //注意此函数可能会返回null
            if (destPort == null)
            {
                return Items.Find(item => item.DestAddr == logicAddr);
            }
            else
            {
                RoutingItem? tmp = Items.Find(item => item.DestAddr == logicAddr && item.DestPort == destPort);
                if (tmp != null)
                {
                    return tmp;
                }
                else
                {
                    //!!修正一下本地端口没有服务的时候不可达的问题，需要了解是哪种匹配（端口/地址）
                    return Items.Find(item => item.DestAddr == logicAddr);
                }
            }
        }
        /// <summary>
        /// 没有匹配的结果会返回null
        /// </summary>
        /// <param name="logicAddr">注意：Big Endian字节序</param>
        /// <returns></returns>
        public Queue<RoutingPackge> GetQueueByAddr(byte[] logicAddr, byte[] destPort = null)
        {
            //注意此函数可能会返回null
            RoutingItem? tmp = Query(logicAddr, destPort);
            if (tmp != null)
            {
                return tmp?.OutputQueue;
            }
            else
            {
                return null;
            }

        }

    }

    public struct RoutingItem
    {
        public byte[] DestAddr;
        public byte[] DestPort;
        public Queue<RoutingPackge> OutputQueue;
        public RoutingItem(byte[] destAddr, Queue<RoutingPackge> outputQueue, byte[] destPort = null)
        {
            DestAddr = destAddr;
            OutputQueue = outputQueue;
            DestPort = destPort;
        }
    }
}
