﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YBTVPN_Server
{
    public static class Log
    {
        public static void Logging(string str)
        {
            Console.WriteLine("{0:G} {1}", DateTime.Now, str);
        }

        public static void Logging(string str,ConsoleColor ForegroundColor, ConsoleColor BackgroundColor)
        {
            Console.ForegroundColor = ForegroundColor;
            Console.BackgroundColor = BackgroundColor;
            Console.WriteLine("{0:G} {1}", DateTime.Now, str);
        }
    }
}
