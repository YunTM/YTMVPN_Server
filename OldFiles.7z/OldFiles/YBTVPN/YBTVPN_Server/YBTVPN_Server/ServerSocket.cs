﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using YBTVPN_Server.Object;

namespace YBTVPN_Server
{
    class ServerSocket:Socket
    {
        EndPoint remote; //用来保存客户端的IP和端口号
        byte[] buffer;


        public ServerSocket(SocketInformation socketInformation) : base(socketInformation)
        {

        }
        public ServerSocket(AddressFamily addressFamily, SocketType socketType, ProtocolType protocolType) : base(addressFamily, socketType, protocolType)
        {

        }

        public void StartWork()
        {
            //准备变量
            remote = new IPEndPoint(IPAddress.Any, 0);
            buffer = new byte[4096]; //!MTU这里需要修改

            //异步接收
            this.BeginReceiveFrom(buffer, 0, buffer.Length, 0, ref remote, new AsyncCallback(ServerSocket_ReadCallback), null);

        }

        void ServerSocket_ReadCallback(IAsyncResult ar)
        {
            //接收数据
            int count = this.EndReceiveFrom(ar,ref remote);

            //存入队列
            RoutingObject ro = new RoutingObject()
            {
                endpoint = remote,
                data = new byte[count]
            };
            Buffer.BlockCopy(buffer, 0, ro.data, 0, count);  //Buffer.BlockCopy效率高于Array.Copy
            //!!线程安全
            Program.RoutingQueue.Enqueue(ro);

            //Debug
            Log.Logging("Length: " + count);
            Log.Logging("EndPoint: " + ro.endpoint.ToString());
            Log.Logging("Data: " + Encoding.ASCII.GetString(ro.data));

            //异步接收下一个
            this.BeginReceiveFrom(buffer, 0, buffer.Length, 0, ref remote, new AsyncCallback(ServerSocket_ReadCallback), this);
            
        }

    }
}
