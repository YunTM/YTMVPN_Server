﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace YBTVPN_Server
{
    public class SocketAsyncEventArgsPool
    {
        ConcurrentBag<SocketAsyncEventArgs> bag = new ConcurrentBag<SocketAsyncEventArgs>();
        public Func<SocketAsyncEventArgs> CreateObj;
        public int Max { get; set; }
        public int Count { get{ return bag.Count; } }
        public SocketAsyncEventArgsPool(Func<SocketAsyncEventArgs> createObj , int max = 50) {
            CreateObj = createObj;
            Max = max;
        }
        public SocketAsyncEventArgs GetObj()
        {
            if (bag.TryTake(out SocketAsyncEventArgs obj))
            {
                return obj;
            }
            else
            {
                return CreateObj();
            }
        }
        public void PutObj(SocketAsyncEventArgs obj)
        {
            if (bag.Count >= Max)
            {
                return;
            }
            else
            {
                obj.SetBuffer(0, 4096);
                bag.Add(obj);
            }
        }
    }
}
