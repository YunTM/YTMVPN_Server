﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;

namespace YBTVPN_Server.Routing
{
    public struct RoutingItem
    {
        public byte[] DestAddr;
        public byte[] DestPort;
        public ConcurrentQueue<RoutingPackge> OutputQueue;
        public RoutingItem(byte[] destAddr, ConcurrentQueue<RoutingPackge> outputQueue, byte[] destPort = null)
        {
            DestAddr = destAddr;
            OutputQueue = outputQueue;
            DestPort = destPort;
        }
    }
}
