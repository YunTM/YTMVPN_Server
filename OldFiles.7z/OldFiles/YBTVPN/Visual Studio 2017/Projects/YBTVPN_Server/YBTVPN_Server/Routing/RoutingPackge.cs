﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace YBTVPN_Server.Routing
{
    public struct RoutingPackge
    {
        public EndPoint RemoteEndpoint;
        public byte[] dstAddr;
        public byte[] Data;

        public RoutingPackge(EndPoint remoteEndpoint, byte[] data)
        {
            RemoteEndpoint = remoteEndpoint;
            Data = data;
            dstAddr = null;  //!!注意null
        }
    }
}
