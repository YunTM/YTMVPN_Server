﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Net;
using System.Text;

namespace YBTVPN_Server
{
    public class ServerSocket
    {
        SocketAsyncEventArgsPool readEventArgsPool;
        SocketAsyncEventArgsPool sendEventArgsPool;
        Socket socket;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="addressFamily"></param>
        /// <param name="socketType"></param>
        /// <param name="protocolType"></param>
        public ServerSocket(AddressFamily addressFamily, SocketType socketType, ProtocolType protocolType)
        {
            //准备对象
            readEventArgsPool = new SocketAsyncEventArgsPool(CreateReadEventArgs, 50);
            for (int i = 0; i < 50; i++)
            {
                readEventArgsPool.PutObj(CreateReadEventArgs());
            }

            sendEventArgsPool = new SocketAsyncEventArgsPool(CreateSendEventArgs, 50);
            for (int i = 0; i < 50; i++)
            {
                sendEventArgsPool.PutObj(CreateSendEventArgs());
            }

            //!!!!!异步接收 不会写SocketAsyncArgs啊卧槽
            socket.ReceiveMessageFromAsync(readEventArgsPool.GetObj());

        }

        /// <summary>
        /// readEventArgsPool创建对象时的函数
        /// </summary>
        /// <returns></returns>
        SocketAsyncEventArgs CreateReadEventArgs()
        {
            //remote = new IPEndPoint(IPAddress.Any, 0);
            //buffer = new byte[4096]; //!MTU这里需要修改
            SocketAsyncEventArgs e = new SocketAsyncEventArgs();
            e.SetBuffer(new byte[4096], 0, 4096);
            e.Completed += Read_Completed;
            return e;
        }
        /// <summary>
        /// sendEventArgsPool创建对象时的函数
        /// </summary>
        /// <returns></returns>
        SocketAsyncEventArgs CreateSendEventArgs()
        {
            SocketAsyncEventArgs e = new SocketAsyncEventArgs();
            e.SetBuffer(new byte[4096], 0, 4096);
            e.Completed += Send_Completed;
            return e;
        }

        /// <summary>
        /// 读操作完成
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Read_Completed(object sender, SocketAsyncEventArgs e)
        {
            //先异步接收下一个
            socket.ReceiveMessageFromAsync(readEventArgsPool.GetObj());

            //丢入队列
            Program.RoutingService.RecvQueue.Enqueue(new Routing.RoutingPackge(e.RemoteEndPoint,e.Buffer));

            //还给对象池
            readEventArgsPool.PutObj(e);


            return;
            //!!这是啥？自动生成的
            //throw new NotImplementedException();
        }

        /// <summary>
        /// 发送操作完成
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Send_Completed(object sender, SocketAsyncEventArgs e)
        {
            //还给对象池
            sendEventArgsPool.PutObj(e);

            return;
            //!!这是啥？自动生成的
            //throw new NotImplementedException();
        }

        /// <summary>
        /// 异步发送Raw数据
        /// </summary>
        /// <param name="dst"></param>
        /// <param name="data"></param>
        public void SendAsync(IPEndPoint dst, byte[] data)
        {
            SocketAsyncEventArgs e = sendEventArgsPool.GetObj();
            e.RemoteEndPoint = dst;
            e.SetBuffer(data, 0, data.Length);
            socket.SendToAsync(e);
        }



        //void ServerSocket_ReadCallback(IAsyncResult ar)
        //{
        //    //接收数据
        //    int count = this.EndReceiveFrom(ar, ref remote);

        //    //存入队列
        //    RoutingObject ro = new RoutingObject()
        //    {
        //        endpoint = remote,
        //        data = new byte[count]
        //    };
        //    Buffer.BlockCopy(buffer, 0, ro.data, 0, count);  //Buffer.BlockCopy效率高于Array.Copy
        //    //!!线程安全
        //    Program.RoutingQueue.Enqueue(ro);

        //    //Debug
        //    Log.Logging("Length: " + count);
        //    Log.Logging("EndPoint: " + ro.endpoint.ToString());
        //    Log.Logging("Data: " + Encoding.ASCII.GetString(ro.data));

        //    //异步接收下一个
        //    this.BeginReceiveFrom(buffer, 0, buffer.Length, 0, ref remote, new AsyncCallback(ServerSocket_ReadCallback), this);

        //}
    }
}
