﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace YBTVPN_Server.Control
{
    public struct EndpointItem
    {
        public EndPoint EP;
        public byte[] LogicAddr;
        public EndpointStatus Status;

        public EndpointItem(EndPoint ep ,byte[] logicAddr, EndpointStatus status = EndpointStatus.Unknown)
        {
            EP = ep;
            LogicAddr = logicAddr;
            Status = status;
        }
    }
}
