﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace YBTVPN_Server.Control
{
    public class EndpointTable
    {
        public List<EndpointItem> Items = new List<EndpointItem>();
        //public byte[] GetAddrByEndpoint(EndPoint ep)
        //{
        //    return Items.Find(item => item.EP == ep).LogicAddr;
        //}

        public EndpointItem GetItemByEndpoint(EndPoint ep)
        {
            return Items.Find(item => item.EP == ep);
        }

        public void Add(EndPoint ep , byte[] logicAddr,EndpointStatus status)
        {
            Items.Add(new EndpointItem(ep, logicAddr, status));
        }

        
    }
}
