﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YBTVPN_Server.Control
{
    public enum EndpointStatus
    {
        Unknown = 0,
        Hello = 1,
        Success = 2
        
    }
}
