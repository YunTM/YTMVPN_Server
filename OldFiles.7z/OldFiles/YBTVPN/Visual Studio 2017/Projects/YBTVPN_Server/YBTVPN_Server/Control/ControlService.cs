﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading;
using YBTVPN_Server.Routing;

namespace YBTVPN_Server.Control
{
    public class ControlService
    {
        //Flag常量
        public const byte Hello = 0x00;
        public const byte HelloAck = 0x01;
        public const byte HelloSuccess = 0x02;
        public const byte 

        public ConcurrentQueue<RoutingPackge> ServiceQueue = new ConcurrentQueue<RoutingPackge>();
        public EndpointTable EndpointTable = new EndpointTable();
        public void Do()
        {
            while (true)
            {
                while (!ServiceQueue.IsEmpty)
                {
                    if (ServiceQueue.TryDequeue(out RoutingPackge rp))
                    {
                        //查询EndpointTable
                        //byte[] remoteLogicAddr = EndpointTable.GetAddrByEndpoint(rp.RemoteEndpoint);
                        //!!!index可能会被改变！！
                        int remoteIndex = EndpointTable.GetItemIndexByEndpoint(rp.RemoteEndpoint);
                        EndpointItem remote = EndpointTable.Items[remoteIndex];
                        
                        if (remote.LogicAddr == null)
                        {
                            //没有Endpoint记录，按照Hello包解析
                                if (PackgeHelper.VerifyHello(rp.Data, out remote.LogicAddr))
                                {
                                    //添加到EndpointTable，状态Hello
                                    EndpointTable.Add(rp.RemoteEndpoint, remote.LogicAddr,EndpointStatus.Hello);
                                    //发送Hello-Ack
                                    Program.RoutingService.SendQueue.Enqueue(
                                        PackgeHelper.PackHelloAck(
                                            rp.RemoteEndpoint, 
                                            remote.LogicAddr, 
                                            Program.LogicAddrByteArray));
                                }
                            
                        }
                        else
                        {
                            //找到Endpoint记录
                            if (remote.Status == EndpointStatus.Hello && PackgeHelper.VerifyHelloSuccess(rp.Data, Program.LogicAddrByteArray))
                            {
                                //Hello-Success
                                remote.Status = EndpointStatus.Success;
                                EndpointTable.Items[remoteIndex] = remote;  //修改状态，写入到Table

                            }

                            //判断Flag
                            switch (rp.Data[Program.options.LogicAddr + Program.options.LogicPortLength])
                            {
                                case HelloSuccess:

                                    break;
                                case :
                                    break;
                                default:
                                    break;
                            }
                          

                        }
                    }
                }
                //休眠
                Thread.Sleep(10);
            }
        }
    }
}
