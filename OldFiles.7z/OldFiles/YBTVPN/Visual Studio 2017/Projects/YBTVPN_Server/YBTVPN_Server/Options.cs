﻿using System;
using System.Collections.Generic;
using System.Text;
using CommandLine;
using CommandLine.Text;

namespace YBTVPN_Server
{

    class Options
    {
        //绑定本地socket IP
        [Option("Bind", Default = "127.0.0.1", HelpText = "Bind IP(Local)")]
        public string Bind { get; set; }

        //绑定本地socket Port
        [Option("Port", Default = (ushort)52145, HelpText = "Bind Port(Local)")]
        public ushort Port { get; set; }

        //逻辑地址长度
        [Option("LogicAddrLength", Default = (ushort)8, HelpText = "Logic Address Length")]
        public ushort LogicAddrLength { get; set; }

        //逻辑地址
        [Option("LogicAddr", Default = (ushort)1, HelpText = "Logic Address")]
        public ushort LogicAddr { get; set; }

        //逻辑端口号长度
        [Option("LogicPortLength", Default = (ushort)1, HelpText = "Logic Port Length")]
        public ushort LogicPortLength { get; set; }

        ////逻辑地址网络号
        ////!!用上了？
        //[Option("LogicNet", Default = (ushort)3, HelpText = "Logic Network")]
        //public ushort LogicNet { get; set; }

        //[HelpOption]
        //public string GetUsage()
        //{
        //    //!现在懒得写
        //    // this without using CommandLine.Text
        //    //  or using HelpText.AutoBuild
        //    var usage = new StringBuilder();
        //    usage.AppendLine("Quickstart Application 1.0");
        //    usage.AppendLine("Read user manual for usage instructions...");
        //    return usage.ToString();
        //}
    }
}
