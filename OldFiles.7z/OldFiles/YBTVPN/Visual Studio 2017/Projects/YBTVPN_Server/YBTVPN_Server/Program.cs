﻿using System;
using CommandLine;
using CommandLine.Text;
using System.Threading;
using YBTVPN_Server.Routing;
using System.Net;
using System.Net.Sockets;
using YBTVPN_Server.Control;

namespace YBTVPN_Server
{

    class Program
    {
        public static Options options;
        public static RoutingService RoutingService = new RoutingService();  //路由服务
        public static ControlService ControlService = new ControlService();  //控制服务
        public static ServerSocket serverSocket;
        public static byte[] LogicAddrByteArray;  //LogicAddr的字节数组
        static void Main(string[] args)
        {
            //!处理参数（判读参数正确性）
            CommandLine.Parser.Default.ParseArguments<Options>(args).WithParsed<Options>(parsed => options = parsed);
            LogHelper.Log("Bind: " + options.Bind);
            LogHelper.Log("Port: " + options.Port);
            LogHelper.Log("LogicAddrLength :" + options.LogicAddrLength);
            LogHelper.Log("LogicAddr: " + options.LogicAddr);
            LogHelper.Log("LogicPortLength :" + options.LogicPortLength);
            //LogHelper.Log("LogicNet: " + options.LogicNet);

            //计算一些数字便于之后工作
            //计算LogicAddrByteArray
            LogicAddrByteArray = BitConverter.GetBytes(options.LogicAddr);
            //!!注意跨平台的字节序
            Array.Reverse(LogicAddrByteArray);

            //计算LogicAddr占用字节
            //LogicAddrByteLength = (ushort)Math.Ceiling((double)(options.LogicAddrLength / 8));
            ////计算LogicAddr所需字节的多余位
            //LogicAddrFreeBit = (ushort)(options.LogicAddrLength % 8);
            ////计算LogicPort占用字节
            //LogicPortByteLength = (ushort)Math.Ceiling((double)((options.LogicPortLength) / 8));
            //计算LogicPort占用字节的偏移
            //LogicPortByteOffset = ;
            //计算LogicPort所需字节的多余位
            //LogicPortFreeBit = (ushort)(options.LogicPortLength % 8);
            ////计算LogicAddrAndPort占用字节
            //LogicAddrAndPortByteLength = (ushort)Math.Ceiling((double)((options.LogicAddrLength + options.LogicPortLength) / 8));
            ////计算LogicAddrAndPort所需字节的多余位
            //LogicPortFreeBit = (ushort)(options.LogicAddrLength + options.LogicPortLength % 8);

            //初始化路由表条目
            Routing.RoutingTable.Add(LogicAddrBoolArray, ControlService.ServiceQueue,);  //控制服务


            //!启动线程池任务
            ThreadPool.QueueUserWorkItem(new WaitCallback(RoutingService.DoRecv));  //路由服务Recv
            ThreadPool.QueueUserWorkItem(new WaitCallback(RoutingService.DoSend));  //路由服务Send
            ThreadPool.QueueUserWorkItem(new WaitCallback(ControlService.Do));  //控制服务


            //绑定socket
            serverSocket = new ServerSocket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            LogHelper.Log("binding " + options.Bind + ":" + options.Port);
            serverSocket.Bind(new IPEndPoint(IPAddress.Parse(options.Bind), options.Port));

            //开始工作
            serverSocket.StartWork();



            //!需要处理退出
            while (true)
            {
                Console.ReadKey();
            }

        }
    }
}