﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using YBTVPN_Server.Routing;

namespace YBTVPN_Server
{
    static class PackgeHelper
    {
        /// <summary>
        /// 验证Hello包中各字段，并返回对方的逻辑地址
        /// </summary>
        /// <param name="data"></param>
        /// <param name="clientAddr"></param>
        /// <returns></returns>
        public static bool VerifyHello(byte[] data ,out byte[] clientAddr)
        {
            //检查Addr Port Flag字段
            for (int i = 0; i < Program.options.LogicAddrLength + Program.options.LogicPortLength + 1; i++)
            {
                if (data[i] != 0x00)
                {
                    clientAddr = null;
                    return false;
                }
            }
            
            clientAddr = new byte[Program.options.LogicAddrLength];
            Buffer.BlockCopy(data, Program.options.LogicAddrLength + Program.options.LogicPortLength + 1, clientAddr, 0, Program.options.LogicAddrLength);
            return true;
        }

        /// <summary>
        /// 验证Hello-Success包中各字段
        /// </summary>
        /// <param name="data"></param>
        /// <param name="clientAddr"></param>
        /// <returns></returns>
        public static bool VerifyHelloSuccess(byte[] data, byte[] localAddr)
        {
            int i = 0;
            //检查Addr
            for (; i < localAddr.Length; i++)
            {
                if (data[i] != localAddr[i]) return false;
            }

            //检查Port
            for (; i < localAddr.Length + Program.options.LogicPortLength; i++)
            {
                if (data[i] != 0x00) return false;
            }

            //检查Flag
            if (data[i] != 0x02) return false;

            return true;
        }
        /// <summary>
        /// 将数据打包成byte[]
        /// </summary>
        /// <param name="dstAddr"></param>
        /// <param name="dstPort"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public static byte[] Pack(byte[] dstAddr, byte[] dstPort, byte[] data)
        {
            List<byte> b = new List<byte>(dstAddr.Length + dstPort.Length + data.Length);
            b.AddRange(dstAddr);
            b.AddRange(dstPort);
            b.AddRange(data);

            return b.ToArray();
        }

        /// <summary>
        /// 生成Hello-Ack包
        /// </summary>
        /// <param name="remoteEndpoint"></param>
        /// <param name="remoteAddr"></param>
        /// <param name="localAddr"></param>
        /// <returns></returns>
        public static RoutingPackge PackHelloAck(EndPoint remoteEndpoint, byte[] remoteAddr,byte[] localAddr)
        {
            List<byte> b = new List<byte>(remoteAddr.Length * 2 + Program.options.LogicPortLength + 1);  //两个地址长度+端口长度+Flag长度
            b.AddRange(remoteAddr);
            b.Add(0x00);
            b.Add(0x01);
            b.AddRange(localAddr);

            return new RoutingPackge(remoteEndpoint, b.ToArray());
        }







    }
}
